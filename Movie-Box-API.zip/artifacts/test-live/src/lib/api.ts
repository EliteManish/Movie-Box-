const BASE = "/api";

async function apiFetch<T>(path: string): Promise<T> {
  const res = await fetch(`${BASE}${path}`);
  if (!res.ok) throw new Error(`API error ${res.status}: ${path}`);
  const json = await res.json();
  if (!json.success) throw new Error(json.error ?? "API error");
  return json.data as T;
}

/* ─── MovieBox item shape (from V3 tab-operating / search) ─── */
export interface SubjectItem {
  subjectId?: string;
  id?: string | number;
  /* V3 tab-operating & search */
  title?: string;
  cover?: { url?: string };
  imdbRate?: string;
  imdbRatingValue?: string;
  releaseDate?: string;
  genre?: string;
  subjectType?: number;       /* 1=MOVIES, 2=TV_SERIES, 7=ANIME */
  description?: string;
  detailPath?: string;
  /* fallbacks from older endpoints */
  name?: string;
  poster?: string;
  coverImageUrl?: string;
  score?: number;
  rating?: number;
  year?: number;
  genres?: string[];
  type?: string;
  category?: string;
}

export interface SubjectDetail extends SubjectItem {
  backdrop?: string;
  backgroundImg?: string;
  introduction?: string;
  plot?: string;
  totalSeasons?: number;
  seasons?: SeasonItem[];
  season?: number;
  episodeCount?: number;
  episodes?: number;
}

export interface SeasonItem {
  season?: number;
  seNum?: number;
  seasonNum?: number;
  name?: string;
  title?: string;
  episodes?: EpisodeItem[];
  episodeList?: EpisodeItem[];
}

export interface EpisodeItem {
  episode?: number;
  ep?: number;
  episodeNum?: number;
  name?: string;
  title?: string;
  cover?: { url?: string };
  poster?: string;
  duration?: number;
}

export interface StreamItem {
  /* resource endpoint */
  resourceLink?: string;
  /* play endpoint */
  url?: string;
  /* fallbacks */
  videoUrl?: string;
  quality?: string;
  resolution?: number | string;
  /* title like "Avatar-360P" — used as quality label */
  title?: string;
  size?: string | number;
  format?: string;
  /* series-specific: episode/season number for this stream */
  ep?: number;
  se?: number;
  codecName?: string;
  duration?: number;
}

export interface PlayInfo {
  playUrl?: string;
  url?: string;
  hlsUrl?: string;
  type?: string;
}

export interface SubtitleItem {
  url?: string;
  language?: string;
  lang?: string;
  name?: string;
}

/* ─── Banner item (from tab-operating BANNER section) ─── */
export interface BannerItem {
  image?: { url?: string };
  content?: string;
  deepLink?: string;
}

/* ─── Helpers ─── */

export function getSubjectId(item: SubjectItem): string {
  return item.subjectId ?? String(item.id ?? "");
}

export function getPoster(item: SubjectItem | SubjectDetail): string {
  return item.cover?.url ?? item.coverImageUrl ?? item.poster ?? "";
}

export function getName(item: SubjectItem | SubjectDetail): string {
  return item.title ?? item.name ?? "Untitled";
}

export function getScore(item: SubjectItem | SubjectDetail): number {
  const raw = (item as SubjectItem).imdbRate ?? (item as SubjectItem).imdbRatingValue ??
    (item as SubjectItem).score ?? (item as SubjectItem).rating;
  if (!raw) return 0;
  const n = typeof raw === "number" ? raw : parseFloat(String(raw));
  return isNaN(n) ? 0 : n;
}

export function getYear(item: SubjectItem | SubjectDetail): number {
  if ((item as SubjectItem).year) return (item as SubjectItem).year!;
  const rd = (item as SubjectItem).releaseDate;
  if (rd) {
    const y = parseInt(rd.split("-")[0] ?? "0", 10);
    return isNaN(y) ? 0 : y;
  }
  return 0;
}

export function getDescription(item: SubjectDetail): string {
  return item.description ?? item.introduction ?? item.plot ?? "";
}

export function getGenres(item: SubjectItem | SubjectDetail): string[] {
  if (Array.isArray(item.genres) && item.genres.length) return item.genres;
  const g = (item as SubjectItem).genre;
  if (g) return g.split(",").map((s) => s.trim()).filter(Boolean);
  return [];
}

export function getSubjectTypeString(item: SubjectItem): string {
  const t = item.subjectType;
  if (t === 1) return "MOVIES";
  if (t === 2) return "TV_SERIES";
  if (t === 7) return "ANIME";
  return item.type ?? item.category ?? "MOVIES";
}

export function isSeriesItem(item: SubjectItem): boolean {
  const t = item.subjectType;
  if (t !== undefined) return t === 2 || t === 7;
  const s = item.type ?? item.category ?? "";
  return s === "TV_SERIES" || s === "ANIME";
}

export function isSeriesType(typeStr?: string): boolean {
  if (!typeStr) return false;
  return typeStr === "TV_SERIES" || typeStr === "ANIME";
}

/* Parses subjectId from a deepLink like:
   oneroom://com.community.oneroom?type=/movie/detail&id=<subjectId>&subject_type=2 */
export function parseDeepLinkId(deepLink?: string): string {
  if (!deepLink) return "";
  try {
    const qStart = deepLink.indexOf("?");
    if (qStart === -1) return "";
    const params = new URLSearchParams(deepLink.slice(qStart + 1));
    return params.get("id") ?? "";
  } catch {
    return "";
  }
}

/* Homepage banner item (operatingList structure) */
export interface HomeBannerItem {
  subjectId?: string;
  title?: string;
  image?: { url?: string };
  subjectType?: number;
}

/* Extract banners from any known API response */
export function extractBanners(data: unknown): BannerItem[] {
  if (!data) return [];
  const d = data as Record<string, unknown>;

  /* Trending: { items: Section[] } → BANNER section has banner.banners[] */
  const sectionsA = Array.isArray(d.items) ? (d.items as Record<string, unknown>[]) : [];
  for (const section of sectionsA) {
    if (section.type === "BANNER" || section.type === "banner") {
      const b = section.banner as Record<string, unknown> | undefined;
      if (b && Array.isArray(b.banners) && b.banners.length) return b.banners as BannerItem[];
    }
  }

  /* Homepage: { operatingList: Section[] } → BANNER section has banner.items[] */
  const sectionsB = Array.isArray(d.operatingList) ? (d.operatingList as Record<string, unknown>[]) : [];
  for (const section of sectionsB) {
    if (section.type === "BANNER") {
      const b = section.banner as Record<string, unknown> | undefined;
      if (b && Array.isArray(b.items) && b.items.length) {
        /* Convert homepage banner items to BannerItem shape */
        return (b.items as HomeBannerItem[]).map((item) => ({
          image: item.image,
          content: item.title,
          deepLink: item.subjectId ? `oneroom://x?id=${item.subjectId}` : undefined,
        }));
      }
    }
  }

  return [];
}

/* Extract subjects from homepage operatingList */
function extractFromOperatingList(sections: Record<string, unknown>[]): SubjectItem[] {
  const out: SubjectItem[] = [];
  const seen = new Set<string>();
  for (const section of sections) {
    if (Array.isArray(section.subjects)) {
      for (const item of section.subjects as SubjectItem[]) {
        const id = getSubjectId(item);
        if (id && !seen.has(id)) { seen.add(id); out.push(item); }
        else if (!id) out.push(item);
      }
    }
  }
  return out;
}

/* Extract subject items from ANY known response shape */
export function extractItems(data: unknown): SubjectItem[] {
  if (!data) return [];
  if (Array.isArray(data)) return data as SubjectItem[];

  const d = data as Record<string, unknown>;

  /* Tab-operating: { items: Section[] } each section has subjects[] */
  if (Array.isArray(d.items)) {
    const items = extractFromOperatingList(d.items as Record<string, unknown>[]);
    if (items.length > 0) return items;
  }

  /* Homepage: { operatingList: Section[] } each section has subjects[] */
  if (Array.isArray(d.operatingList)) {
    const items = extractFromOperatingList(d.operatingList as Record<string, unknown>[]);
    if (items.length > 0) return items;
  }

  /* Hot content: { movie: [...], tv: [...] } */
  if (Array.isArray(d.movie)) {
    const out: SubjectItem[] = [...(d.movie as SubjectItem[])];
    if (Array.isArray(d.tv)) out.push(...(d.tv as SubjectItem[]));
    return out;
  }

  /* Search / generic list */
  if (Array.isArray(d.list)) return d.list as SubjectItem[];
  if (Array.isArray(d.data)) return d.data as SubjectItem[];
  if (Array.isArray(d.postList)) return d.postList as SubjectItem[];
  if (Array.isArray(d.subjectList)) return d.subjectList as SubjectItem[];

  return [];
}

export function getStreamItems(data: Record<string, unknown>): StreamItem[] {
  /* resource endpoint: { list: StreamItem[] }  */
  const list = (data?.list ?? data?.downloads ?? data?.resources ?? data?.streams ?? []) as StreamItem[];
  return Array.isArray(list) ? list : [];
}

export function getStreamUrl(s: StreamItem): string {
  return s.resourceLink ?? s.url ?? s.videoUrl ?? "";
}

export function getStreamLabel(s: StreamItem, index: number): string {
  if (s.title) {
    /* Extract quality suffix: "Avatar-360P" → "360P" */
    const m = s.title.match(/(\d+[Pp]|4K|8K|HD|FHD|SD)$/);
    if (m) return m[1];
    if (s.title.trim()) return s.title;
  }
  /* Use numeric resolution field: 480 → "480P" */
  if (s.resolution) return `${s.resolution}P`;
  return s.quality ?? `Q${index + 1}`;
}

export function getPlayUrl(data: Record<string, unknown>): string {
  return (data?.playUrl ?? data?.url ?? data?.hlsUrl ?? "") as string;
}

export function getSubtitles(data: Record<string, unknown>): SubtitleItem[] {
  const subs = (data?.subtitles ?? data?.captions ?? []) as SubtitleItem[];
  return Array.isArray(subs) ? subs : [];
}

export function proxyStream(url: string): string {
  return `/api/proxy/stream?url=${encodeURIComponent(url)}`;
}

export function proxySub(url: string): string {
  return `/api/proxy/sub?url=${encodeURIComponent(url)}`;
}

/* ─── API surface ─── */
export const api = {
  trending: (page = 1, tab = 0) =>
    apiFetch<unknown>(`/trending?page=${page}&tab=${tab}`),
  trendingMovies: () => apiFetch<unknown>("/trending/movies"),
  trendingSeries: () => apiFetch<unknown>("/trending/series"),
  hot: () => apiFetch<unknown>("/hot"),
  homepage: () => apiFetch<unknown>("/homepage"),
  popularSearches: () => apiFetch<unknown>("/popular-searches"),

  search: (q: string, page = 1, type?: string) =>
    apiFetch<unknown>(`/search?q=${encodeURIComponent(q)}&page=${page}${type ? `&type=${type}` : ""}`),
  suggest: (q: string) =>
    apiFetch<unknown>(`/search/suggest?q=${encodeURIComponent(q)}`),

  movieDetails: (id: string) =>
    apiFetch<{ subject: SubjectDetail; streams: StreamItem[]; resource: Record<string, unknown> }>(
      `/movie/details?id=${id}`,
    ),
  seriesDetails: (id: string, season?: number) =>
    apiFetch<{ info: SubjectDetail; episodes: unknown }>(
      `/series/details?id=${id}${season !== undefined ? `&season=${season}` : ""}`,
    ),
  season: (id: string, season?: number) =>
    apiFetch<unknown>(`/season?id=${id}${season !== undefined ? `&season=${season}` : ""}`),

  episodeResource: (id: string, season = 0, episode = 0) =>
    apiFetch<Record<string, unknown>>(`/episode/resource?id=${id}&season=${season}&episode=${episode}`),
  episodePlay: (id: string, season = 0, episode = 0) =>
    apiFetch<Record<string, unknown>>(`/episode/play?id=${id}&season=${season}&episode=${episode}`),
};
