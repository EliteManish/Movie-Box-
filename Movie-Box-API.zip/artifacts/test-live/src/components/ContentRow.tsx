import { useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { MovieCard } from "./MovieCard";
import { extractItems, type SubjectItem } from "@/lib/api";

interface ContentRowProps {
  title: string;
  data: unknown;
  loading?: boolean;
  size?: "sm" | "md" | "lg";
}

export function ContentRow({ title, data, loading, size = "md" }: ContentRowProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  const items: SubjectItem[] = extractItems(data);

  function scroll(dir: "left" | "right") {
    if (!scrollRef.current) return;
    const by = scrollRef.current.clientWidth * 0.75;
    scrollRef.current.scrollBy({ left: dir === "left" ? -by : by, behavior: "smooth" });
  }

  return (
    <div className="mb-10">
      <div className="flex items-center justify-between mb-4 px-4 md:px-8">
        <h2 className="font-display text-lg md:text-xl font-semibold text-foreground">{title}</h2>
        <div className="flex gap-2">
          <button
            onClick={() => scroll("left")}
            className="w-8 h-8 rounded-full glass flex items-center justify-center hover:bg-primary/20 transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            onClick={() => scroll("right")}
            className="w-8 h-8 rounded-full glass flex items-center justify-center hover:bg-primary/20 transition-colors"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div
        ref={scrollRef}
        className="flex gap-3 overflow-x-auto scrollbar-hide px-4 md:px-8 pb-2"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
      >
        {loading
          ? Array.from({ length: 8 }).map((_, i) => (
              <div
                key={i}
                className="flex-shrink-0 w-36 md:w-44 aspect-[2/3] rounded-xl shimmer"
              />
            ))
          : items.length > 0
          ? items.map((item, i) => (
              <MovieCard key={`${item.subjectId ?? item.id ?? i}`} item={item} size={size} />
            ))
          : null}
      </div>
    </div>
  );
}
