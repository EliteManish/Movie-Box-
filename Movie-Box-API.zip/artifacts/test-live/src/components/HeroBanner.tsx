import { useState, useEffect, useCallback } from "react";
import { useLocation } from "wouter";
import { Play, Info, Star, ChevronLeft, ChevronRight } from "lucide-react";
import {
  type BannerItem,
  extractBanners,
  extractItems,
  getSubjectId,
  getPoster,
  getName,
  getScore,
  getYear,
  getGenres,
  parseDeepLinkId,
  type SubjectItem,
} from "@/lib/api";

/* Banner can come from tab-operating BANNER section or from extractItems */
type HeroItem = {
  id: string;
  poster: string;
  title: string;
  score: number;
  year: number;
  genres: string[];
};

function fromBanner(b: BannerItem): HeroItem | null {
  const id = parseDeepLinkId(b.deepLink);
  if (!id) return null;
  return {
    id,
    poster: b.image?.url ?? "",
    title: b.content ?? "",
    score: 0,
    year: 0,
    genres: [],
  };
}

function fromSubject(s: SubjectItem): HeroItem | null {
  const id = getSubjectId(s);
  if (!id) return null;
  return {
    id,
    poster: getPoster(s),
    title: getName(s),
    score: getScore(s),
    year: getYear(s),
    genres: getGenres(s),
  };
}

interface HeroBannerProps {
  data: unknown;
  loading?: boolean;
}

export function HeroBanner({ data, loading }: HeroBannerProps) {
  const [, setLocation] = useLocation();
  const [idx, setIdx] = useState(0);
  const [fading, setFading] = useState(false);

  /* Try banners first (richer images), fall back to subjects */
  const banners: HeroItem[] = (() => {
    const bItems = extractBanners(data).map(fromBanner).filter(Boolean) as HeroItem[];
    if (bItems.length >= 3) return bItems.slice(0, 8);
    const sItems = extractItems(data).slice(0, 8).map(fromSubject).filter(Boolean) as HeroItem[];
    return [...bItems, ...sItems].slice(0, 8);
  })();

  const go = useCallback(
    (next: number) => {
      setFading(true);
      setTimeout(() => { setIdx(next); setFading(false); }, 280);
    },
    [],
  );

  const prev = () => go((idx - 1 + banners.length) % banners.length);
  const next = useCallback(() => go((idx + 1) % banners.length), [idx, banners.length, go]);

  useEffect(() => {
    if (banners.length < 2) return;
    const t = setInterval(next, 6000);
    return () => clearInterval(t);
  }, [banners.length, next]);

  if (loading) {
    return <div className="w-full h-[480px] md:h-[560px] shimmer" />;
  }

  if (!banners.length) return null;

  const item = banners[idx];

  return (
    <div className="relative w-full h-[480px] md:h-[560px] overflow-hidden bg-card mb-10">
      {/* Backdrop */}
      <div
        className="absolute inset-0 transition-opacity duration-300"
        style={{ opacity: fading ? 0 : 1 }}
      >
        {item.poster ? (
          <img src={item.poster} alt={item.title} className="w-full h-full object-cover object-center" />
        ) : (
          <div className="w-full h-full bg-secondary" />
        )}
      </div>

      {/* Gradients */}
      <div className="absolute inset-0 bg-gradient-to-r from-background via-background/75 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />

      {/* Content */}
      <div
        className="absolute inset-0 flex flex-col justify-end pb-14 px-8 md:px-16 transition-opacity duration-300"
        style={{ opacity: fading ? 0 : 1 }}
      >
        {item.genres.length > 0 && (
          <div className="flex gap-2 mb-3 flex-wrap">
            {item.genres.slice(0, 3).map((g) => (
              <span key={g} className="text-xs font-medium px-2.5 py-1 rounded-full glass text-primary border border-primary/30">
                {g}
              </span>
            ))}
          </div>
        )}

        <h1 className="font-display text-3xl md:text-5xl font-bold text-white mb-3 max-w-xl leading-tight drop-shadow-lg">
          {item.title}
        </h1>

        <div className="flex items-center gap-4 mb-6 text-sm text-white/80">
          {item.score > 0 && (
            <span className="flex items-center gap-1">
              <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
              <span className="font-semibold text-white">{item.score.toFixed(1)}</span>
            </span>
          )}
          {item.year > 0 && <span>{item.year}</span>}
        </div>

        <div className="flex gap-3">
          <button className="btn-primary" onClick={() => setLocation(`/watch?id=${item.id}`)}>
            <Play className="w-4 h-4 fill-white" /> Watch Now
          </button>
          <button className="btn-glass" onClick={() => setLocation(`/watch?id=${item.id}`)}>
            <Info className="w-4 h-4" /> Details
          </button>
        </div>
      </div>

      {/* Arrows */}
      {banners.length > 1 && (
        <>
          <button onClick={prev} className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-primary/20 transition-colors z-10">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button onClick={next} className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-primary/20 transition-colors z-10">
            <ChevronRight className="w-5 h-5" />
          </button>
        </>
      )}

      {/* Dots */}
      {banners.length > 1 && (
        <div className="absolute bottom-5 left-1/2 -translate-x-1/2 flex gap-1.5">
          {banners.map((_, i) => (
            <button key={i} onClick={() => go(i)} className={`h-1.5 rounded-full transition-all ${i === idx ? "w-6 bg-primary" : "w-1.5 bg-white/30"}`} />
          ))}
        </div>
      )}
    </div>
  );
}
