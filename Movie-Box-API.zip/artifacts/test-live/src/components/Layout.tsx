import { useState } from "react";
import { useLocation } from "wouter";
import { Search, Film, Home, TrendingUp, Tv2, Heart } from "lucide-react";
import { SearchModal } from "./SearchModal";

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [location, setLocation] = useLocation();
  const [searchOpen, setSearchOpen] = useState(false);

  const navItems = [
    { label: "Home", href: "/", icon: Home },
    { label: "Movies", href: "/browse?type=MOVIES", icon: Film },
    { label: "Series", href: "/browse?type=TV_SERIES", icon: Tv2 },
    { label: "Trending", href: "/browse", icon: TrendingUp },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-40 glass-dark border-b border-border/50">
        <div className="max-w-screen-2xl mx-auto px-4 md:px-8 h-16 flex items-center gap-6">
          {/* Logo */}
          <button
            onClick={() => setLocation("/")}
            className="flex items-center gap-2 flex-shrink-0"
          >
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <Film className="w-4 h-4 text-white" />
            </div>
            <span className="font-display font-bold text-xl text-gradient hidden sm:block">
              CineStream
            </span>
          </button>

          {/* Nav */}
          <nav className="hidden md:flex items-center gap-1 flex-1">
            {navItems.map(({ label, href, icon: Icon }) => {
              const active = href === "/" ? location === "/" : location.startsWith(href.split("?")[0]);
              return (
                <button
                  key={label}
                  onClick={() => setLocation(href)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    active
                      ? "text-primary bg-primary/10"
                      : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {label}
                </button>
              );
            })}
          </nav>

          {/* Search */}
          <div className="ml-auto flex items-center gap-2">
            <button
              onClick={() => setSearchOpen(true)}
              className="flex items-center gap-2 px-3 py-2 rounded-lg glass text-muted-foreground hover:text-foreground hover:bg-white/5 transition-colors text-sm"
            >
              <Search className="w-4 h-4" />
              <span className="hidden sm:block">Search…</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-1 pt-16">{children}</main>

      {/* Footer */}
      <footer className="mt-16 border-t border-border py-8 px-8 text-center">
        <div className="flex items-center justify-center gap-1.5 text-sm text-muted-foreground">
          <span>made with</span>
          <Heart className="w-4 h-4 text-accent fill-accent" />
          <span>by NZ R</span>
        </div>
        <p className="mt-2 text-xs text-muted-foreground/50">
          For educational purposes only. All content belongs to their respective owners.
        </p>
      </footer>

      <SearchModal open={searchOpen} onClose={() => setSearchOpen(false)} />
    </div>
  );
}
