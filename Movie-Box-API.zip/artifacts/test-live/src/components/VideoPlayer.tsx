import { useEffect, useRef, useState, useCallback } from "react";
import Hls from "hls.js";
import {
  Play, Pause, Volume2, VolumeX, Maximize, Minimize,
  Settings, Subtitles, ChevronDown, Loader2, SkipBack, SkipForward,
  AlertTriangle,
} from "lucide-react";
import { proxyStream, proxySub, getStreamUrl, getStreamLabel, type StreamItem, type SubtitleItem } from "@/lib/api";

interface VideoPlayerProps {
  streams?: StreamItem[];
  playInfo?: Record<string, unknown>;
  subtitles?: SubtitleItem[];
  title?: string;
  onEnded?: () => void;
  autoPlay?: boolean;
}

function fmtTime(s: number): string {
  if (!isFinite(s)) return "0:00";
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2, "0")}`;
}

function canPlayH265(): boolean {
  const v = document.createElement("video");
  return (
    v.canPlayType('video/mp4; codecs="hvc1"') !== "" ||
    v.canPlayType('video/mp4; codecs="hev1"') !== "" ||
    v.canPlayType('video/mp4; codecs="dvh1"') !== ""
  );
}

export function VideoPlayer({
  streams = [],
  playInfo,
  subtitles = [],
  title,
  onEnded,
  autoPlay = false,
}: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const hideTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  const [playing, setPlaying] = useState(false);
  const [loading, setLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [muted, setMuted] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  const [controlsVisible, setControlsVisible] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [showSubs, setShowSubs] = useState(false);
  const [selectedRes, setSelectedRes] = useState(0);
  const [selectedSub, setSelectedSub] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [codecWarning, setCodecWarning] = useState(false);
  const [buffered, setBuffered] = useState(0);

  /* ── Resolve source ── */
  const resolvedStreams = streams.filter((s) => getStreamUrl(s).length > 4);

  const hlsUrl = (() => {
    const raw = playInfo?.playUrl ?? playInfo?.url ?? playInfo?.hlsUrl;
    return typeof raw === "string" && raw ? raw : null;
  })();

  const useHls = Boolean(hlsUrl);
  const directUrl = resolvedStreams[selectedRes] ? getStreamUrl(resolvedStreams[selectedRes]) : null;
  const videoSrc = useHls ? hlsUrl : directUrl ? proxyStream(directUrl) : null;

  const qualityLabels = resolvedStreams.map((s, i) => getStreamLabel(s, i));

  /* ── HLS / direct video setup ── */
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !videoSrc) return;

    setError(null);
    setLoading(true);
    setCodecWarning(false);

    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }

    if (useHls) {
      if (Hls.isSupported()) {
        const hls = new Hls({ enableWorker: true, maxMaxBufferLength: 30 });
        hlsRef.current = hls;
        hls.loadSource(videoSrc);
        hls.attachMedia(video);
        hls.on(Hls.Events.ERROR, (_e, data) => {
          if (data.fatal) setError("Stream failed to load — try another quality.");
        });
      } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
        video.src = videoSrc;
      } else {
        setError("HLS streaming not supported in this browser.");
      }
    } else {
      video.src = videoSrc;
      /* Check H.265 support after a brief delay */
      const codecCheck = setTimeout(() => {
        if (!canPlayH265()) setCodecWarning(true);
      }, 500);
      return () => {
        clearTimeout(codecCheck);
        hlsRef.current?.destroy();
        hlsRef.current = null;
      };
    }

    if (autoPlay) video.play().catch(() => {});

    return () => {
      hlsRef.current?.destroy();
      hlsRef.current = null;
    };
  }, [videoSrc, useHls, autoPlay]);

  /* ── Subtitle track ── */
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    Array.from(video.textTracks).forEach((t) => { t.mode = "hidden"; });
    if (selectedSub === null) return;
    const track = video.textTracks[selectedSub];
    if (track) track.mode = "showing";
  }, [selectedSub]);

  /* ── Controls auto-hide ── */
  const showControls = useCallback(() => {
    setControlsVisible(true);
    clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => {
      if (playing) setControlsVisible(false);
    }, 3000);
  }, [playing]);

  useEffect(() => () => clearTimeout(hideTimer.current), []);

  /* ── Video event handlers ── */
  const onTimeUpdate = () => {
    const v = videoRef.current;
    if (!v) return;
    setCurrentTime(v.currentTime);
    if (v.buffered.length > 0) {
      setBuffered((v.buffered.end(v.buffered.length - 1) / v.duration) * 100 || 0);
    }
  };

  const onLoadedMeta = () => { setDuration(videoRef.current?.duration ?? 0); setLoading(false); };
  const onWaiting = () => setLoading(true);
  const onCanPlay = () => setLoading(false);
  const onPlayEvt = () => setPlaying(true);
  const onPauseEvt = () => setPlaying(false);
  const onErrorEvt = () => {
    const v = videoRef.current;
    const code = v?.error?.code;
    if (code === 4 || !canPlayH265()) {
      setError(null);
      setCodecWarning(true);
    } else {
      setError("Failed to load video. Try a different quality.");
    }
    setLoading(false);
  };

  const togglePlay = () => {
    const v = videoRef.current;
    if (!v) return;
    playing ? v.pause() : v.play();
  };

  const seek = (e: React.MouseEvent<HTMLDivElement>) => {
    const v = videoRef.current;
    if (!v || !duration) return;
    const rect = e.currentTarget.getBoundingClientRect();
    v.currentTime = ((e.clientX - rect.left) / rect.width) * duration;
  };

  const skip = (sec: number) => {
    const v = videoRef.current;
    if (v) v.currentTime = Math.max(0, Math.min(duration, v.currentTime + sec));
  };

  const setVol = (val: number) => {
    setVolume(val);
    if (videoRef.current) videoRef.current.volume = val;
    setMuted(val === 0);
  };

  const toggleMute = () => {
    const v = videoRef.current;
    if (!v) return;
    v.muted = !v.muted;
    setMuted(v.muted);
  };

  const toggleFullscreen = async () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      await containerRef.current.requestFullscreen();
      setFullscreen(true);
    } else {
      await document.exitFullscreen();
      setFullscreen(false);
    }
  };

  useEffect(() => {
    const handler = () => setFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener("fullscreenchange", handler);
    return () => document.removeEventListener("fullscreenchange", handler);
  }, []);

  const progress = duration ? (currentTime / duration) * 100 : 0;

  if (!videoSrc) {
    return (
      <div className="w-full aspect-video bg-black rounded-2xl flex items-center justify-center">
        <div className="text-center text-muted-foreground">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-3 text-primary" />
          <p className="text-sm">Loading stream…</p>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className={`relative w-full aspect-video bg-black rounded-2xl overflow-hidden video-wrapper ${!playing ? "paused" : ""}`}
      onMouseMove={showControls}
      onMouseLeave={() => playing && setControlsVisible(false)}
      style={{ cursor: controlsVisible ? "default" : "none" }}
    >
      {/* Video */}
      <video
        ref={videoRef}
        className="w-full h-full"
        onClick={togglePlay}
        onTimeUpdate={onTimeUpdate}
        onLoadedMetadata={onLoadedMeta}
        onWaiting={onWaiting}
        onCanPlay={onCanPlay}
        onPlay={onPlayEvt}
        onPause={onPauseEvt}
        onEnded={onEnded}
        onError={onErrorEvt}
        playsInline
      >
        {subtitles.map((sub, i) => {
          const src = sub.url ? proxySub(sub.url) : "";
          return src ? (
            <track key={i} kind="subtitles" src={src}
              label={sub.language ?? sub.lang ?? sub.name ?? `Sub ${i + 1}`} />
          ) : null;
        })}
      </video>

      {/* Loading spinner */}
      {loading && !codecWarning && !error && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/40 pointer-events-none">
          <Loader2 className="w-10 h-10 text-primary animate-spin" />
        </div>
      )}

      {/* H.265 codec warning */}
      {codecWarning && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/90">
          <div className="text-center text-white px-8 max-w-sm">
            <AlertTriangle className="w-10 h-10 text-yellow-400 mx-auto mb-3" />
            <p className="font-semibold mb-2">H.265/HEVC Codec Required</p>
            <p className="text-sm text-white/70 mb-4 leading-relaxed">
              This stream uses H.265 encoding. For best compatibility, use{" "}
              <strong>Safari</strong> on macOS/iOS, or Chrome on Windows with
              the HEVC Video Extensions installed.
            </p>
            {resolvedStreams.length > 1 && (
              <div className="flex flex-wrap gap-2 justify-center">
                {qualityLabels.map((label, i) => (
                  <button
                    key={i}
                    onClick={() => { setSelectedRes(i); setCodecWarning(false); setLoading(true); }}
                    className={`px-3 py-1.5 rounded-lg text-sm transition-colors ${i === selectedRes ? "bg-primary text-white" : "glass hover:bg-white/10"}`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Error */}
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/80">
          <div className="text-center text-white px-6">
            <p className="text-sm mb-3">{error}</p>
            <button
              className="btn-primary text-xs"
              onClick={() => {
                setError(null);
                setLoading(true);
                if (videoRef.current) { videoRef.current.load(); videoRef.current.play().catch(() => {}); }
              }}
            >
              Retry
            </button>
          </div>
        </div>
      )}

      {/* Controls */}
      <div
        className="video-controls absolute inset-0 flex flex-col justify-end bg-gradient-to-t from-black/90 via-transparent to-black/30"
        style={{ opacity: controlsVisible ? 1 : 0, pointerEvents: controlsVisible ? "auto" : "none" }}
      >
        {title && (
          <div className="absolute top-4 left-4 right-4">
            <p className="text-white font-semibold text-sm truncate drop-shadow">{title}</p>
          </div>
        )}

        {/* Quality popup */}
        {showSettings && resolvedStreams.length > 1 && (
          <div className="absolute bottom-20 right-4 glass-dark rounded-xl p-3 min-w-36 z-20 shadow-2xl">
            <p className="text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wider">Quality</p>
            {qualityLabels.map((label, i) => (
              <button key={i} onClick={() => { setSelectedRes(i); setShowSettings(false); setLoading(true); }}
                className={`w-full text-left px-3 py-1.5 rounded-lg text-sm transition-colors ${i === selectedRes ? "bg-primary text-white" : "hover:bg-white/10 text-foreground"}`}
              >
                {label}
              </button>
            ))}
          </div>
        )}

        {/* Subtitle popup */}
        {showSubs && (
          <div className="absolute bottom-20 right-14 glass-dark rounded-xl p-3 min-w-36 z-20 shadow-2xl">
            <p className="text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wider">Subtitles</p>
            <button onClick={() => { setSelectedSub(null); setShowSubs(false); }}
              className={`w-full text-left px-3 py-1.5 rounded-lg text-sm transition-colors ${selectedSub === null ? "bg-primary text-white" : "hover:bg-white/10 text-foreground"}`}
            >
              Off
            </button>
            {subtitles.map((sub, i) => (
              <button key={i} onClick={() => { setSelectedSub(i); setShowSubs(false); }}
                className={`w-full text-left px-3 py-1.5 rounded-lg text-sm transition-colors ${i === selectedSub ? "bg-primary text-white" : "hover:bg-white/10 text-foreground"}`}
              >
                {sub.language ?? sub.lang ?? sub.name ?? `Track ${i + 1}`}
              </button>
            ))}
          </div>
        )}

        {/* Bottom bar */}
        <div className="px-4 pb-4">
          {/* Progress */}
          <div className="w-full h-1 bg-white/20 rounded-full cursor-pointer mb-3 relative" onClick={seek}>
            <div className="absolute h-full bg-white/30 rounded-full" style={{ width: `${buffered}%` }} />
            <div className="absolute h-full bg-primary rounded-full" style={{ width: `${progress}%` }} />
            <div className="absolute top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full shadow-lg"
              style={{ left: `calc(${progress}% - 6px)` }} />
          </div>

          <div className="flex items-center gap-2">
            <button onClick={() => skip(-10)} className="text-white/80 hover:text-white">
              <SkipBack className="w-4 h-4" />
            </button>
            <button onClick={togglePlay}
              className="w-9 h-9 rounded-full bg-white flex items-center justify-center hover:bg-white/90 transition-colors flex-shrink-0"
            >
              {playing
                ? <Pause className="w-4 h-4 text-black" />
                : <Play className="w-4 h-4 text-black fill-black ml-0.5" />}
            </button>
            <button onClick={() => skip(10)} className="text-white/80 hover:text-white">
              <SkipForward className="w-4 h-4" />
            </button>
            <button onClick={toggleMute} className="text-white/80 hover:text-white ml-1">
              {muted || volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
            <input type="range" min={0} max={1} step={0.05} value={muted ? 0 : volume}
              onChange={(e) => setVol(parseFloat(e.target.value))}
              className="w-20 accent-primary h-1" />
            <span className="text-white/70 text-xs ml-2">
              {fmtTime(currentTime)} / {fmtTime(duration)}
            </span>
            <div className="flex-1" />
            {subtitles.length > 0 && (
              <button onClick={() => { setShowSubs((v) => !v); setShowSettings(false); }}
                className={`text-white/80 hover:text-white transition-colors ${showSubs ? "text-primary" : ""}`}>
                <Subtitles className="w-4 h-4" />
              </button>
            )}
            {resolvedStreams.length > 1 && (
              <button onClick={() => { setShowSettings((v) => !v); setShowSubs(false); }}
                className={`text-white/80 hover:text-white transition-colors flex items-center gap-1 ${showSettings ? "text-primary" : ""}`}>
                <Settings className="w-4 h-4" />
                <span className="text-xs hidden sm:block">{qualityLabels[selectedRes]}</span>
                <ChevronDown className="w-3 h-3" />
              </button>
            )}
            <button onClick={toggleFullscreen} className="text-white/80 hover:text-white">
              {fullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
