import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { Search, X, Loader2 } from "lucide-react";
import { api, extractItems, getSubjectId, getPoster, getName, getYear, type SubjectItem } from "@/lib/api";

interface SearchModalProps {
  open: boolean;
  onClose: () => void;
}

export function SearchModal({ open, onClose }: SearchModalProps) {
  const [, setLocation] = useLocation();
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<SubjectItem[]>([]);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const timerRef = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  useEffect(() => {
    if (open) {
      setTimeout(() => inputRef.current?.focus(), 100);
    } else {
      setQuery("");
      setResults([]);
    }
  }, [open]);

  useEffect(() => {
    clearTimeout(timerRef.current);
    if (!query.trim()) { setResults([]); return; }

    timerRef.current = setTimeout(async () => {
      setLoading(true);
      try {
        const data = await api.search(query);
        setResults(extractItems(data).slice(0, 12));
      } catch {
        setResults([]);
      } finally {
        setLoading(false);
      }
    }, 400);

    return () => clearTimeout(timerRef.current);
  }, [query]);

  function handleSelect(item: SubjectItem) {
    const id = getSubjectId(item);
    if (id) {
      setLocation(`/watch?id=${id}`);
      onClose();
    }
  }

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-16 px-4"
      onClick={onClose}
    >
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
      <div
        className="relative w-full max-w-xl glass-dark rounded-2xl overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Input */}
        <div className="flex items-center gap-3 px-4 py-3.5 border-b border-border">
          <Search className="w-5 h-5 text-muted-foreground flex-shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search movies, series, anime…"
            className="flex-1 bg-transparent text-foreground placeholder:text-muted-foreground text-base outline-none"
          />
          {loading ? (
            <Loader2 className="w-4 h-4 text-muted-foreground animate-spin" />
          ) : query ? (
            <button onClick={() => setQuery("")}>
              <X className="w-4 h-4 text-muted-foreground hover:text-foreground" />
            </button>
          ) : null}
        </div>

        {/* Results */}
        {results.length > 0 && (
          <div className="max-h-96 overflow-y-auto divide-y divide-border">
            {results.map((item) => {
              const id = getSubjectId(item);
              const poster = getPoster(item);
              const name = getName(item);
              const year = getYear(item);
              return (
                <button
                  key={id}
                  onClick={() => handleSelect(item)}
                  className="w-full flex items-center gap-3 px-4 py-3 hover:bg-white/5 transition-colors text-left"
                >
                  {poster ? (
                    <img
                      src={poster}
                      alt={name}
                      className="w-10 h-14 rounded-md object-cover flex-shrink-0"
                    />
                  ) : (
                    <div className="w-10 h-14 rounded-md bg-secondary flex-shrink-0" />
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-foreground truncate">{name}</p>
                    {year > 0 && <p className="text-xs text-muted-foreground mt-0.5">{year}</p>}
                  </div>
                </button>
              );
            })}
          </div>
        )}

        {query && !loading && results.length === 0 && (
          <div className="px-4 py-8 text-center text-muted-foreground text-sm">
            No results for "{query}"
          </div>
        )}
      </div>
    </div>
  );
}
