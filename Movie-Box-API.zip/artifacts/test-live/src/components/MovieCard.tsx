import { useState } from "react";
import { useLocation } from "wouter";
import { Star, Play } from "lucide-react";
import { type SubjectItem, getSubjectId, getPoster, getName, getScore, getYear } from "@/lib/api";

interface MovieCardProps {
  item: SubjectItem;
  size?: "sm" | "md" | "lg";
}

export function MovieCard({ item, size = "md" }: MovieCardProps) {
  const [, setLocation] = useLocation();
  const [imgError, setImgError] = useState(false);
  const [hovered, setHovered] = useState(false);

  const id = getSubjectId(item);
  const poster = getPoster(item);
  const name = getName(item);
  const score = getScore(item);
  const year = getYear(item);

  const dims =
    size === "sm"
      ? "w-32 md:w-36"
      : size === "lg"
      ? "w-44 md:w-52"
      : "w-36 md:w-44";

  function handleClick() {
    if (id) setLocation(`/watch?id=${id}`);
  }

  return (
    <div
      className={`${dims} flex-shrink-0 cursor-pointer group`}
      onClick={handleClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div className="relative aspect-[2/3] rounded-xl overflow-hidden bg-secondary card-hover">
        {poster && !imgError ? (
          <img
            src={poster}
            alt={name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            onError={() => setImgError(true)}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-secondary">
            <span className="text-muted-foreground text-xs text-center px-2 leading-tight">{name}</span>
          </div>
        )}

        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

        {hovered && (
          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <div className="w-12 h-12 rounded-full bg-primary/90 flex items-center justify-center shadow-lg">
              <Play className="w-5 h-5 text-white fill-white ml-0.5" />
            </div>
          </div>
        )}

        {score > 0 && (
          <div className="absolute top-2 left-2 flex items-center gap-1 bg-black/60 backdrop-blur-sm rounded-md px-1.5 py-0.5">
            <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
            <span className="text-xs font-semibold text-white">{score.toFixed(1)}</span>
          </div>
        )}
      </div>

      <div className="mt-2 px-0.5">
        <p className="text-sm font-medium text-foreground truncate leading-tight">{name}</p>
        {year > 0 && <p className="text-xs text-muted-foreground mt-0.5">{year}</p>}
      </div>
    </div>
  );
}
