import { useEffect, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { HeroBanner } from "@/components/HeroBanner";
import { ContentRow } from "@/components/ContentRow";
import { MovieCard } from "@/components/MovieCard";
import { api, extractItems, type SubjectItem } from "@/lib/api";
import { Loader2 } from "lucide-react";

export default function Home() {
  const [hotPage, setHotPage] = useState(1);
  const [hotItems, setHotItems] = useState<SubjectItem[]>([]);
  const [loadingMore, setLoadingMore] = useState(false);
  const sentinelRef = useRef<HTMLDivElement>(null);

  const { data: trendingMovies, isLoading: loadTM } = useQuery({
    queryKey: ["trending-movies"],
    queryFn: () => api.trendingMovies(),
  });

  const { data: trendingSeries, isLoading: loadTS } = useQuery({
    queryKey: ["trending-series"],
    queryFn: () => api.trendingSeries(),
  });

  const { data: hotData, isLoading: loadHot } = useQuery({
    queryKey: ["hot"],
    queryFn: () => api.hot(),
  });

  const { data: homepage, isLoading: loadHP } = useQuery({
    queryKey: ["homepage"],
    queryFn: () => api.homepage(),
  });

  const { data: trendingAll, isLoading: loadTA } = useQuery({
    queryKey: ["trending-all", hotPage],
    queryFn: () => api.trending(hotPage, 0),
    enabled: hotPage > 1,
  });

  /* Infinite scroll — accumulate items */
  useEffect(() => {
    if (!hotData) return;
    const items = extractItems(hotData);
    if (hotPage === 1) setHotItems(items);
  }, [hotData, hotPage]);

  useEffect(() => {
    if (hotPage <= 1 || !trendingAll) return;
    const items = extractItems(trendingAll);
    setHotItems((prev) => {
      const ids = new Set(prev.map((x) => x.subjectId ?? x.id));
      return [...prev, ...items.filter((x) => !ids.has(x.subjectId ?? x.id))];
    });
    setLoadingMore(false);
  }, [trendingAll, hotPage]);

  /* IntersectionObserver for infinite scroll */
  useEffect(() => {
    const el = sentinelRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !loadingMore) {
          setLoadingMore(true);
          setHotPage((p) => p + 1);
        }
      },
      { rootMargin: "200px" },
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [loadingMore]);

  const heroData = homepage ?? trendingMovies;

  return (
    <div className="pb-8">
      <HeroBanner data={heroData} loading={loadHP && loadTM} />

      <ContentRow title="Trending Movies" data={trendingMovies} loading={loadTM} />
      <ContentRow title="Trending Series" data={trendingSeries} loading={loadTS} />

      {/* Infinite scroll grid */}
      <section className="px-4 md:px-8">
        <h2 className="font-display text-lg md:text-xl font-semibold text-foreground mb-4">
          Popular Right Now
        </h2>
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-7 gap-3">
          {loadHot && hotItems.length === 0
            ? Array.from({ length: 14 }).map((_, i) => (
                <div key={i} className="aspect-[2/3] rounded-xl shimmer" />
              ))
            : hotItems.map((item, i) => (
                <MovieCard
                  key={`${item.subjectId ?? item.id ?? i}`}
                  item={item}
                  size="sm"
                />
              ))}
        </div>

        {/* Sentinel */}
        <div ref={sentinelRef} className="h-4 mt-8" />
        {loadingMore && (
          <div className="flex justify-center py-4">
            <Loader2 className="w-6 h-6 animate-spin text-primary" />
          </div>
        )}
      </section>
    </div>
  );
}
