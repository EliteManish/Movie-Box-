import { useEffect, useRef, useState } from "react";
import { useSearch } from "wouter";
import { MovieCard } from "@/components/MovieCard";
import { api, extractItems, type SubjectItem } from "@/lib/api";
import { Loader2, Film, Tv2, Sword } from "lucide-react";

type ContentFilter = "ALL" | "MOVIES" | "TV_SERIES" | "ANIME";

const FILTERS: { label: string; value: ContentFilter; icon: React.ReactNode }[] = [
  { label: "All", value: "ALL", icon: <Film className="w-4 h-4" /> },
  { label: "Movies", value: "MOVIES", icon: <Film className="w-4 h-4" /> },
  { label: "Series", value: "TV_SERIES", icon: <Tv2 className="w-4 h-4" /> },
  { label: "Anime", value: "ANIME", icon: <Sword className="w-4 h-4" /> },
];

export default function Browse() {
  const searchStr = useSearch();
  const params = new URLSearchParams(searchStr);
  const initialType = (params.get("type") as ContentFilter) ?? "ALL";

  const [filter, setFilter] = useState<ContentFilter>(initialType);
  const [page, setPage] = useState(1);
  const [items, setItems] = useState<SubjectItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const sentinelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setItems([]);
    setPage(1);
    setHasMore(true);
  }, [filter]);

  useEffect(() => {
    const abortCtrl = new AbortController();
    const load = async () => {
      page === 1 ? setLoading(true) : setLoadingMore(true);
      try {
        const typeParam = filter !== "ALL" ? filter : undefined;
        const data = await api.trending(page, filter === "MOVIES" ? 1 : filter === "TV_SERIES" ? 2 : 0);
        if (abortCtrl.signal.aborted) return;
        const fetched = extractItems(data);
        const filtered =
          typeParam ? fetched.filter((x) => x.type === typeParam || x.category === typeParam) : fetched;
        setItems((prev) => {
          if (page === 1) return filtered;
          const ids = new Set(prev.map((x) => x.subjectId ?? x.id));
          return [...prev, ...filtered.filter((x) => !ids.has(x.subjectId ?? x.id))];
        });
        if (fetched.length < 10) setHasMore(false);
      } catch {
        if (!abortCtrl.signal.aborted) setHasMore(false);
      } finally {
        setLoading(false);
        setLoadingMore(false);
      }
    };
    load();
    return () => abortCtrl.abort();
  }, [filter, page]);

  /* IntersectionObserver */
  useEffect(() => {
    const el = sentinelRef.current;
    if (!el || !hasMore) return;
    const obs = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !loadingMore && !loading) {
          setPage((p) => p + 1);
        }
      },
      { rootMargin: "200px" },
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [hasMore, loadingMore, loading]);

  return (
    <div className="px-4 md:px-8 pt-8 pb-12">
      {/* Filter tabs */}
      <div className="flex gap-2 mb-8 flex-wrap">
        {FILTERS.map(({ label, value, icon }) => (
          <button
            key={value}
            onClick={() => setFilter(value)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
              filter === value
                ? "bg-primary text-white shadow-lg shadow-primary/30"
                : "glass text-muted-foreground hover:text-foreground"
            }`}
          >
            {icon}
            {label}
          </button>
        ))}
      </div>

      {/* Grid */}
      {loading ? (
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-7 gap-3">
          {Array.from({ length: 21 }).map((_, i) => (
            <div key={i} className="aspect-[2/3] rounded-xl shimmer" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-7 gap-3">
          {items.map((item, i) => (
            <MovieCard key={`${item.subjectId ?? item.id ?? i}`} item={item} size="sm" />
          ))}
        </div>
      )}

      <div ref={sentinelRef} className="h-4 mt-8" />
      {loadingMore && (
        <div className="flex justify-center py-4">
          <Loader2 className="w-6 h-6 animate-spin text-primary" />
        </div>
      )}
      {!hasMore && items.length > 0 && (
        <p className="text-center text-muted-foreground text-sm py-4">
          You've reached the end
        </p>
      )}
    </div>
  );
}
