import { useState, useEffect } from "react";
import { useSearch, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Star, Calendar, Play, ChevronDown, ChevronUp, Loader2 } from "lucide-react";
import { VideoPlayer } from "@/components/VideoPlayer";
import {
  api,
  extractItems,
  getPoster,
  getName,
  getScore,
  getYear,
  getDescription,
  getGenres,
  getSubjectId,
  getStreamItems,
  getPlayUrl,
  getSubtitles,
  isSeriesItem,
  type SubjectItem,
  type StreamItem,
  type SubtitleItem,
} from "@/lib/api";

/* Season metadata from the API: { subjectId, subjectType, seasons: [{se, maxEp, allEp}] } */
interface SeasonMeta { se: number; maxEp: number; allEp?: string; }

interface EpButtonProps { num: number; active: boolean; onClick: () => void; }
function EpButton({ num, active, onClick }: EpButtonProps) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-2 w-full px-3 py-2 rounded-xl text-left transition-all text-sm ${
        active
          ? "bg-primary text-white shadow-md shadow-primary/30"
          : "hover:bg-white/5 text-muted-foreground hover:text-foreground"
      }`}
    >
      <span className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 text-xs font-bold ${active ? "bg-white/20" : "bg-secondary"}`}>
        {num}
      </span>
      <span>Episode {num}</span>
    </button>
  );
}

export default function Watch() {
  const [, setLocation] = useLocation();
  const searchStr = useSearch();
  const params = new URLSearchParams(searchStr);
  const id = params.get("id") ?? "";

  const [season, setSeason] = useState(1);
  const [episode, setEpisode] = useState(1);
  const [showAllEps, setShowAllEps] = useState(false);

  const [streams, setStreams] = useState<StreamItem[]>([]);
  const [playInfo, setPlayInfo] = useState<Record<string, unknown> | undefined>();
  const [subtitles, setSubtitles] = useState<SubtitleItem[]>([]);
  const [streamLoading, setStreamLoading] = useState(false);
  const [streamError, setStreamError] = useState<string | null>(null);

  /* ── Subject detail ── */
  const { data: movieData, isLoading: detailLoading } = useQuery({
    queryKey: ["movie-details", id],
    queryFn: () => api.movieDetails(id),
    enabled: Boolean(id),
    retry: 1,
  });

  const subject = movieData?.subject;
  const isSeries = subject ? isSeriesItem(subject) : false;

  /* ── Season info for series ── */
  const { data: seasonData, isLoading: seasonLoading } = useQuery({
    queryKey: ["season", id, season],
    queryFn: () => api.season(id, season),
    enabled: Boolean(id) && isSeries,
  });

  /* Season API returns { subjectId, subjectType, seasons: [{se, maxEp, allEp}] } */
  const seasonMetas: SeasonMeta[] = (() => {
    if (!seasonData) return [];
    const d = seasonData as Record<string, unknown>;
    if (Array.isArray(d.seasons)) return d.seasons as SeasonMeta[];
    return [];
  })();

  const totalSeasons: number = seasonMetas.length > 0
    ? Math.max(...seasonMetas.map((s) => s.se))
    : 1;

  /* Find episode count for the currently selected season */
  const currentSeasonMeta = seasonMetas.find((s) => s.se === season) ?? seasonMetas[0];
  const maxEp = currentSeasonMeta?.maxEp ?? 0;
  /* Generate episode numbers [1..maxEp] */
  const episodeNums: number[] = maxEp > 0 ? Array.from({ length: maxEp }, (_, i) => i + 1) : [];
  const visibleEps = showAllEps ? episodeNums : episodeNums.slice(0, 20);

  /* ── Load streams when season/episode changes ── */
  useEffect(() => {
    if (!id) return;
    /* For series: fetch all episode resources for the season at once (ep=0) */
    const se = isSeries ? season : 0;
    const ep = isSeries ? 0 : 0;
    const playEp = isSeries ? episode : 0;

    let cancelled = false;
    setStreamLoading(true);
    setStreamError(null);

    Promise.allSettled([
      api.episodeResource(id, se, ep),
      api.episodePlay(id, se, playEp),
    ]).then(([resResult, playResult]) => {
      if (cancelled) return;
      if (resResult.status === "fulfilled") {
        const allStreams = getStreamItems(resResult.value);
        /* Filter to current episode if ep field is present */
        const forEp = isSeries
          ? allStreams.filter((s) => s.ep === undefined || s.ep === episode)
          : allStreams;
        setStreams(forEp.length > 0 ? forEp : allStreams.slice(0, 1));
        setSubtitles(getSubtitles(resResult.value));
      }
      if (playResult.status === "fulfilled") {
        const url = getPlayUrl(playResult.value);
        if (url) setPlayInfo(playResult.value);
        const subs = getSubtitles(playResult.value);
        if (subs.length > 0) setSubtitles(subs);
      }
      if (
        resResult.status === "rejected" &&
        playResult.status === "rejected"
      ) {
        setStreamError("Could not load streams. The content may be unavailable.");
      }
      setStreamLoading(false);
    });

    return () => { cancelled = true; };
  }, [id, season, episode, isSeries]);

  /* ── Recommendations ── */
  const { data: recData } = useQuery({
    queryKey: ["trending-movies"],
    queryFn: () => api.trendingMovies(),
    staleTime: 300_000,
  });
  const recItems = extractItems(recData).slice(0, 12);

  if (!id) {
    return (
      <div className="flex items-center justify-center h-64 text-muted-foreground">
        No content ID provided.
      </div>
    );
  }

  const poster = subject ? getPoster(subject) : "";
  const name = subject ? getName(subject) : "";
  const score = subject ? getScore(subject) : 0;
  const year = subject ? getYear(subject) : 0;
  const desc = subject ? getDescription(subject) : "";
  const genres = subject ? getGenres(subject) : [];

  return (
    <div className="max-w-screen-2xl mx-auto px-4 md:px-8 py-6">
      <div className="flex flex-col xl:flex-row gap-6">
        {/* LEFT: Player + Info */}
        <div className="flex-1 min-w-0">
          {/* Player */}
          <div className="w-full">
            {streamLoading ? (
              <div className="w-full aspect-video bg-black rounded-2xl flex items-center justify-center">
                <Loader2 className="w-10 h-10 text-primary animate-spin" />
              </div>
            ) : streamError ? (
              <div className="w-full aspect-video bg-black rounded-2xl flex items-center justify-center">
                <div className="text-center text-muted-foreground px-6">
                  <p className="text-sm">{streamError}</p>
                </div>
              </div>
            ) : (
              <VideoPlayer
                streams={streams}
                playInfo={playInfo}
                subtitles={subtitles}
                title={name}
                onEnded={() => {
                  if (isSeries && episode < maxEp) {
                    setEpisode((e) => e + 1);
                  }
                }}
              />
            )}
          </div>

          {/* Info below player */}
          <div className="mt-6">
            {detailLoading ? (
              <div className="space-y-3">
                <div className="h-7 w-2/3 shimmer rounded-lg" />
                <div className="h-4 w-1/3 shimmer rounded" />
                <div className="h-20 shimmer rounded-xl" />
              </div>
            ) : subject ? (
              <>
                {/* Genres */}
                {genres.length > 0 && (
                  <div className="flex gap-2 flex-wrap mb-3">
                    {genres.map((g) => (
                      <span
                        key={g}
                        className="text-xs px-2.5 py-1 rounded-full glass border border-border text-muted-foreground"
                      >
                        {g}
                      </span>
                    ))}
                  </div>
                )}

                <h1 className="font-display text-2xl md:text-3xl font-bold text-foreground mb-2">
                  {name}
                  {isSeries && maxEp > 0 && (
                    <span className="text-lg font-normal text-muted-foreground ml-3">
                      S{season}E{episode}
                    </span>
                  )}
                </h1>

                <div className="flex items-center gap-4 mb-4 text-sm text-muted-foreground">
                  {score > 0 && (
                    <span className="flex items-center gap-1 text-foreground">
                      <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                      <span className="font-semibold">{score.toFixed(1)}</span>
                    </span>
                  )}
                  {year > 0 && (
                    <span className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      {year}
                    </span>
                  )}
                  {isSeries && totalSeasons > 0 && (
                    <span>{totalSeasons} Season{totalSeasons !== 1 ? "s" : ""}</span>
                  )}
                </div>

                {desc && (
                  <p className="text-muted-foreground text-sm leading-relaxed max-w-2xl line-clamp-3">
                    {desc}
                  </p>
                )}
              </>
            ) : null}
          </div>

          {/* Recommendations */}
          {recItems.length > 0 && (
            <div className="mt-10">
              <h2 className="font-display text-lg font-semibold text-foreground mb-4">
                You may also like
              </h2>
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-3">
                {recItems.map((item) => {
                  const rid = getSubjectId(item);
                  const rp = getPoster(item);
                  const rn = getName(item);
                  return (
                    <button
                      key={rid}
                      onClick={() => { setLocation(`/watch?id=${rid}`); window.scrollTo(0, 0); }}
                      className="group relative aspect-[2/3] rounded-xl overflow-hidden bg-secondary card-hover"
                    >
                      {rp && (
                        <img
                          src={rp}
                          alt={rn}
                          className="w-full h-full object-cover"
                        />
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                      <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <Play className="w-8 h-8 text-white fill-white" />
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* RIGHT: Episode list (series only) */}
        {isSeries && (
          <aside className="xl:w-80 flex-shrink-0">
            <div className="glass rounded-2xl p-4">
              {/* Season selector */}
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-display font-semibold text-base">Episodes</h3>
                {totalSeasons > 1 && (
                  <select
                    value={season}
                    onChange={(e) => { setSeason(Number(e.target.value)); setEpisode(0); }}
                    className="bg-secondary text-foreground text-sm rounded-lg px-2 py-1 outline-none border border-border"
                  >
                    {Array.from({ length: totalSeasons }, (_, i) => i + 1).map((s) => (
                      <option key={s} value={s}>
                        Season {s}
                      </option>
                    ))}
                  </select>
                )}
              </div>

              {seasonLoading ? (
                <div className="space-y-2">
                  {Array.from({ length: 6 }).map((_, i) => (
                    <div key={i} className="h-10 shimmer rounded-xl" />
                  ))}
                </div>
              ) : episodeNums.length === 0 ? (
                <p className="text-muted-foreground text-sm text-center py-4">
                  Episode info unavailable
                </p>
              ) : (
                <>
                  <div className="space-y-1">
                    {visibleEps.map((num) => (
                      <EpButton
                        key={num}
                        num={num}
                        active={num === episode}
                        onClick={() => setEpisode(num)}
                      />
                    ))}
                  </div>
                  {episodeNums.length > 20 && (
                    <button
                      onClick={() => setShowAllEps((v) => !v)}
                      className="w-full mt-3 py-2 text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center justify-center gap-1"
                    >
                      {showAllEps ? (
                        <>Show less <ChevronUp className="w-3 h-3" /></>
                      ) : (
                        <>Show all {episodeNums.length} episodes <ChevronDown className="w-3 h-3" /></>
                      )}
                    </button>
                  )}
                </>
              )}
            </div>
          </aside>
        )}
      </div>
    </div>
  );
}
